class BiLiveChat_TesterPanel {
    static Tester(){
        
    }
}